import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/Customer';


@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  cbalance:number;
  router:Router;
  isShowBalance:boolean=true;
  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  showBalance(data:any){
    this.cbalance=this.service.showBalance(data);
    alert("Current balance : "+this.cbalance)
    this.isShowBalance=!this.isShowBalance;
    this.router.navigate(['app-homepage']);
  }
          
  ngOnInit() {
    this.service.fetchCustomers();;
    this.customers=this.service.getCustomers();
  }


}

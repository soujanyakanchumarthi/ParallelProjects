package com.cg.SpringBootRestJpa.service;

import java.util.List;

import com.cg.SpringBootRestJpa.bean.Product;
//import com.cg.SpringBootRestJpa.exception.ProductException;

public interface ProductService 
{	
		public List<Product> addProduct(Product pro);
		public Product getProductById (int id);
		public void deleteProduct(int id);
		public List<Product> getAllProducts() ;
		public List<Product> updateProduct (int id, Product pro);
		public List<Product> findByQuantity();
	

}

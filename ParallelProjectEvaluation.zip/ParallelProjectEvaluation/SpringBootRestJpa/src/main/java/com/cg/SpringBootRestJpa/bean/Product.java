package com.cg.SpringBootRestJpa.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;


@Entity
@Table(name = "ProductD")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqId")
    @SequenceGenerator(name="seqId", initialValue=50, allocationSize=500, sequenceName = "prod_id")
    @Column(name="id", updatable=false, nullable=false)
	private int id;
	private String name;
	private String model;
	private int quantity;
	private int amount;

	@Min(5000)
	@Max(50000)
	private int price;

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", quantity=" + quantity + ", amount="
				+ amount + ", price=" + price + "]";
	}

	

}

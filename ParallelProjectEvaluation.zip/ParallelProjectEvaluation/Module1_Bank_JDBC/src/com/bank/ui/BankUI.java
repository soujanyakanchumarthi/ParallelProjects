package com.bank.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.IncompleteTransactionException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;
import com.bank.services.BankService;

public class BankUI
{
	static Scanner sc = new Scanner(System.in);
	static BankService service = new BankService();

	public static void main(String[] args) throws  IncompleteTransactionException, ClassNotFoundException, SQLException, ZeroBalanceException, AccountNotCreatedException{


   String press1;
		int c,balance;
		String choice,name,password;
		String phoneNo ;
		while(true) {

			System.out.println("1.Create account");
			System.out.println("2.Show balance");
			System.out.println("3.Deposit balance");
			System.out.println("4.Withdraw money");
			System.out.println("5.Fund transfer");
			System.out.println("6.Print transaction");
			System.out.println("7.Exit");
			
          	
				System.out.println("Enter Your choice : ");
			    press1 = sc.next();
			 
			if(press1.matches("[a-z]*")||press1.matches("[A-Z]*"))
			{	     
				System.out.println("Invalid Choice!!!");
				main(null);
            }
			
			
			switch (press1) {
			case "1":


				System.out.println("WELCOME");


				do
				{
					System.out.println("Enter your name");
					name = sc.next();
					c =service.nameValidate(name);
				}
				while(c!=1);
			
				do
				{
					System.out.println("Enter your phone number");
					phoneNo = sc.next();
					c = service.mobNoValidate(phoneNo);
				}
				while(c!=1);
                 
				long phone1 = Long.parseLong(phoneNo);
				long accountNo = phone1 + 456;

				do
				{
					System.out.println("Create password");
					password = sc.next();
					c = service.passwordValidate(password);
				}
				while(c!=1);

				do
				{
					System.out.println("enter balance");
					balance = sc.nextInt();
					c = service.checkBalance(balance);
				}
				while(c!=1);
             try
             {
				boolean result =  service.createAccount(name,phoneNo,password,accountNo,balance);
				if(result)
				{
					System.out.println("Account created successful");
				}
				else
				{
						throw new AccountNotCreatedException();
				}
					} catch (AccountNotCreatedException e) {
						System.out.println(e);
						//e.printStackTrace();
					}
				
				break;

			case "2":

				System.out.println("Enter your account number");
				accountNo = sc.nextLong();
				System.out.println("Enter your password");
				password = sc.next();
				boolean b1= service.validateAccount(accountNo,password);
				if(b1)
				{

					try {
						balance = service.showBalance(accountNo);
						if(balance!=0)
						{
							System.out.println("Your account balance is "+balance);
						}
						else
						{
							throw new ZeroBalanceException();
						}
					}
					catch (ZeroBalanceException e) 
					{
						System.out.println(e);
					}
				}
				else
				{
					System.out.println("Wrong credentials");
				}

				break;
			case "3":
				System.out.println("Enter your account number");
				accountNo = sc.nextLong();
				System.out.println("Enter your password");
				password = sc.next();
				boolean b= service.validateAccount(accountNo,password);
				if(b)
				{
					System.out.println("Enter the amount to be deposited");
					int deposit = sc.nextInt();
					balance = service.depositAmount(accountNo,deposit);
					System.out.println("Amount deposited");
					System.out.println("your new balance is "+balance);
				}
				else
				{
					System.out.println("wrong credentials");
				}
				break;
			case "4":

				System.out.println("Enter your account number");
				accountNo = sc.nextLong();
				System.out.println("Enter your password");
				password = sc.next();
				b= service.validateAccount(accountNo,password);
				if(b)
				{
					System.out.println("Enter the amount to be withdrawal");
					int withdraw = sc.nextInt();
					try
					{
						balance = service.withdrawAmount(accountNo,withdraw);
						if(balance>=0)
						{
							System.out.println("Amount withdrawal");
							System.out.println("You debited "+withdraw);
							System.out.println("your new balance is "+balance+"\n");
						}
						else
						{

							throw new InsufficientBalanceException();

						}
					}
					catch(InsufficientBalanceException e)
					{
						System.out.println(e);
					}
				}
				else
				{
				
					try {
						throw new AccountNotCreatedException();
					    }
					catch (AccountNotCreatedException e) 
					{
						System.out.println(e);
					}
				}
				break;
				
			case "5":

				System.out.println("Enter your account number");
				accountNo = sc.nextLong();
				System.out.println("Enter your password");
				password = sc.next();
				b= service.validateAccount(accountNo,password);
				if(b)
				{
					System.out.println("\nEnter account no to transfer");
					long  accno = sc.nextLong();
					System.out.println("Enter the amount you want to transfer");
					int amount = sc.nextInt();
					boolean transfer = service.fundTransfer(accountNo, accno, amount);
					if(transfer)
					{
						System.out.println(amount+ " is transferred successfully\n");
					}
					else
					{
						throw new IncompleteTransactionException();
					}
				}
				else
				{
					try {
						throw new AccountNotCreatedException();
					    }
					catch (AccountNotCreatedException e) 
					{
						System.out.println(e);
					}
				}

				break;
			case "6":
				System.out.println("Enter your account number");
				accountNo = sc.nextLong();
				System.out.println("Enter your password");
				password = sc.next();
				b= service.validateAccount(accountNo,password);
				if(b)
				{
                    String st=service.getTransaction(accountNo);

					System.out.println("----------Account Statement----------\n");

					System.out.println(st);

				}else {
					System.out.println("Account not exist!");
				}
				break;
				
			case "7": System.exit(0);
			}


		}
	}


}




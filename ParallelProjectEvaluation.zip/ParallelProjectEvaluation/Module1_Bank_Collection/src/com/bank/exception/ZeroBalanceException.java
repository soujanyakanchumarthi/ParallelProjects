package com.bank.exception;

public class ZeroBalanceException extends Exception{
	public String toString()
	{
		return "You have 0 balance";
	}
}

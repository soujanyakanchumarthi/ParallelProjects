package com.bank.dao;

import com.bank.beans.BankBean;
import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;

public interface BankDaoI {
   boolean createAccount(BankBean bankBean) throws AccountNotCreatedException;
   
   int showBalance(long accountNo) throws ZeroBalanceException;
   int depositBalance(long accountNo, int deposit);
   int withdrawBalance(long accountNo, int withdraw) throws InsufficientBalanceException;
   boolean transferFund(long accountNo, long accno, int amount);
   boolean accountValidate(long accountNo,String password);
}

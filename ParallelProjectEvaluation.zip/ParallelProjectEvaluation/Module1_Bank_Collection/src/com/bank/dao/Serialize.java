package com.bank.dao;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Serialize implements Serializable {
     public static void main(String[] args) throws IOException {
		Employee e = new Employee();
		e.setEid(1);
		e.setEname("souj");
		FileOutputStream fs = new FileOutputStream("abc.txt");
		ObjectOutputStream os = new ObjectOutputStream(fs);
		os.writeObject(e);
		System.out.println("done");
	}
}
class Employee implements Serializable
{
	private int eid;
	private String ename;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	
}

package com.bank.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Deserialize
{
public static void main(String[] args) throws IOException, ClassNotFoundException {
	FileInputStream fs = new FileInputStream("abc.txt");
	ObjectInputStream os = new ObjectInputStream(fs);
	Employee e =(Employee)os.readObject();
	System.out.println(e.getEid());
	System.out.println(e.getEname());
}
}

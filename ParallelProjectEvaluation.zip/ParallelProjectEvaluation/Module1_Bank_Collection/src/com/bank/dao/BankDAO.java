package com.bank.dao;

import java.util.HashMap;

import com.bank.beans.BankBean;
import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;

public class BankDAO
{
	HashMap<Long,BankBean> hm;

	BankBean bean = new BankBean();
	long accountNo;
	public BankDAO()
	{
		hm= new HashMap<Long,BankBean>();
	}
	public boolean createAccount(BankBean bankBean) throws AccountNotCreatedException
	
	{
		accountNo = bankBean.getAccountNo();
		System.out.println(accountNo);
		if(!hm.containsKey(accountNo))
		{
			hm.put(accountNo,bankBean);
			System.out.println(hm);
			return true;
		}
		else
		return false;
	}


	public int showBalance(long accountNo) throws ZeroBalanceException
	{
		int balance=0;
		if(hm.containsKey(accountNo))
		{
		    bean=(BankBean)hm.get(accountNo);
			balance = bean.getBalance();
		}
		else
		{
			System.out.println("Account doesn't exists");
		}
		return balance;
	}
	
	public int depositBalance(long accountNo, int deposit)
	{
		int balance=0;
		if(hm.containsKey(accountNo))
		{
			 bean = (BankBean)hm.get(accountNo);
			balance = bean.getBalance()+deposit;
			bean.setMini(" Amount credited rs."+ deposit+ "\n");
			bean.setBalance(balance);
			hm.put(accountNo, bean);
			String s =bean.getMini()+" Amount deposited rs."+ deposit+ "\n";
			bean.setMini(s);
		}
		return balance;
	}
	
	public int  withdrawBalance(long accountNo, int withdraw) throws InsufficientBalanceException
	{
		int balance=0;
		if(hm.containsKey(accountNo))
		{
			  bean = (BankBean)hm.get(accountNo);
		  int bal1 =bean.getBalance();
		  if(bal1<withdraw)
			  return 0;
		  else
			  balance = bal1-withdraw;
		  bean.setBalance(balance);
		  String s =bean.getMini()+" Amount withdrawal rs."+ withdraw+ "\n";
			bean.setMini(s);
				  hm.put(accountNo, bean);
		}
		return balance;
	}
	public boolean transferFund(long accountNo, long accno, int amount)
	{
		int bal1;
	    bean =(BankBean)hm.get(accountNo);
		BankBean bean1 = (BankBean)hm.get(accno);
		if(bean.getBalance()<amount)
			return false;
		else
		 bal1 = bean.getBalance() - amount;
		bean.setBalance(bal1);
		hm.put(accountNo, bean);
		
		int bal2 = bean1.getBalance() + amount;
		bean1.setBalance(bal2);
		String s=bean.getMini()+" Amount debited rs."+ amount+ "\n";

		String s1=bean1.getMini()+" Amount credited rs."+ amount+ "\n";
		bean.setMini(s);
		bean1.setMini(s1);
		
		
		hm.put(accno, bean1);
		return true;
	}
	public boolean accountValidate(long accountNo,String password)
	{
		if(hm.containsKey(accountNo))
		
		     bean= (BankBean)hm.get(accountNo);
			String pass = bean.getPassword();
			if(pass.equals(password))
				return true;
			else 
				return false;
	}
	public String miniStatement(long accountNo) 
	{
		 bean= (BankBean)hm.get(accountNo);
			String str = bean.getMini();
			
			return str;
		
	}
}

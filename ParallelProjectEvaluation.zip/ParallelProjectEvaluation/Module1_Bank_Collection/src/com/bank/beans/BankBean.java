package com.bank.beans;

public class BankBean {
	
	private String name;

	private long accountNo;
	private String password;
	private String phoneNo;
	private int balance;
	private String mini;
    private int i=0;
	public String getMini() {
		return mini;
	}

	public void setMini(String mini) {
		this.mini = mini;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Name=" + name + ", AccountNo=" + accountNo + ", Password="
				+ password + ", PhoneNo=" + phoneNo + ", Balance=" + balance;
	}

}

package com.order.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.order.entities.Order;

@Repository
public interface DaoImpl extends JpaRepository<Order, Integer> {

	
	@Query("From Order WHERE quantity > ?1 and quantity < ?2")
	List<Order> findByQuantity(int quantity1,int quantity2);
	
	@Query("From Order WHERE amount > ?1")
	List<Order> findByAmount(double amount);

}

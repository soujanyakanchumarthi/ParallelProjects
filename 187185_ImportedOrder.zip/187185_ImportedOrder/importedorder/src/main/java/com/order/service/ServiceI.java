package com.order.service;

import java.util.List;
import java.util.Optional;

import com.order.entities.Order;

public interface ServiceI {

	List<Order> createOrder(Order ord);
	
	List<Order> viewAllOrder();
	
	List<Order> updateOrder(Order ord);
	
	List<Order> findByQuantity(int quantity1,int quantity2);
	
	List<Order> findByAmount(double amount);
	
	
}

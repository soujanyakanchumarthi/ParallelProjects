package com.order.service;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.entities.Order;
import com.order.exceptions.GlobalException;
import com.order.repository.DaoImpl;

@Service
public class ServiceImpl implements ServiceI {

	@Autowired
	DaoImpl service;

	@Override
	public List<Order> createOrder(Order ord) {
		
		double price = ord.getPrice();
		int quantity = ord.getQuantity();
		double amount = price * quantity * 75;
		double charges = amount * 1.25 / 100;
		
		ord.setAmount(amount);
		ord.setCharges(charges);
		
		service.save(ord);
		
		return service.findAll();
	}

	@Override
	public List<Order> viewAllOrder() {
		// TODO Auto-generated method stub
		return service.findAll();
	}

	@Override
	public List<Order> updateOrder(Order ord) {
		if(service.existsById(ord.getId())) {
			service.save(ord);
			return service.findAll();
		}
		
		return null;
	}

	@Override
	public List<Order> findByQuantity(int quantity1,int quantity2) {
		
		return service.findByQuantity(quantity1,quantity2);
	}

	@Override
	public List<Order> findByAmount(double amount) {
		return service.findByAmount(amount);
	}
}
	
	
